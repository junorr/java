Apache Ignite IPC
-------------------

Contains different Inter-process communication (IPC) implementations for Apache Ignite.
