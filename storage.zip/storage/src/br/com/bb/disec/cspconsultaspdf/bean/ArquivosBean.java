package br.com.bb.disec.cspconsultaspdf.bean;

public class ArquivosBean {
	
	private int cd_aq;
	private String url;
	private long size;
	private String dt;
	private String mtc;
	
	public ArquivosBean(int cd_aq, String url, long size, String dt, String mtc) {
		super();
		this.cd_aq = cd_aq;
		this.url = url;
		this.size = size;
		this.dt = dt;
		this.mtc = mtc;
	}
	
	public ArquivosBean(int cd_aq, String url, long size, String mtc) {
		super();
		this.cd_aq = cd_aq;
		this.url = url;
		this.size = size;
		this.mtc = mtc;
	}	
	
	public int getCd_aq() {
		return cd_aq;
	}
	public void setCd_aq(int cd_aq) {
		this.cd_aq = cd_aq;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public String getDt() {
		return dt;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}
	public String getMtc() {
		return mtc;
	}
	public void setMtc(String mtc) {
		this.mtc = mtc;
	}
	
}
