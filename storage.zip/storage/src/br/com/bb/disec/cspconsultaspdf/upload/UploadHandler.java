package br.com.bb.disec.cspconsultaspdf.upload;

public interface UploadHandler {

	public Object handle() throws Exception;
	
}
