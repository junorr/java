package br.com.bb.disec.cspconsultaspdf.html;

public class Span extends AbstractHtmlElement {

	public static final String NAME = "span";
	
	
	public Span() {
		super(NAME, false);
	}
	
}
