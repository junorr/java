package br.com.bb.disec.cspconsultaspdf.html;

public class BR extends AbstractHtmlElement {
	
	public static final String NAME = "br";
	
	
	public BR() {
		super(NAME, true);
	}

}
