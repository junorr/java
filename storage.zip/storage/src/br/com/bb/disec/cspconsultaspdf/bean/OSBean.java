package br.com.bb.disec.cspconsultaspdf.bean;

import java.io.File;


public class OSBean {
	//static String cam = "file://srncta09012/bb7419publico$/Interna/CESUP%20PATRIMONIO%20E%20SUPRIMENTOS/ORDENS%20DE%20SERVI%C3%87O%202016/01-2016%20-%20Inscri%C3%A7%C3%A3o%20ARH%20Bolsa%20Gradu%C3%A7%C3%A3o.pdf";
	//static String cam = "//Srncta09012/bb7419publico$/Interna/CESUP PATRIMONIO E SUPRIMENTOS/ORDENS DE SERVI�O 2016"; //aqui utilize o diret�rio 
	//static String cam = "M:/Interna/CESUP PATRIMONIO E SUPRIMENTOS/ORDENS DE SERVI�O 2016";
	//static String cam = "C:/kdiDisec/workspace/portalcesup/WebContent/anexos/os";
	//static String cam = "G:/FUNCI/Interna/MICROINFORMATICA/APLICACOES WEB/GIT/portalcesup/WebContent/anexos/os";

	public static File[] percorrePasta(String context){
		
    	//String[] nomes = null;
    	File diretorio = new File(context);
	    if(diretorio.isDirectory()){
	      File[] arquivos = diretorio.listFiles();  
	      
	      //for(int i = 0; i < arquivos.length; i++){  
	      	//nomes[i] = arquivos[i].getAbsolutePath();         
	      //}
	      return arquivos;
	    }
		return null; 
	}
    
}
