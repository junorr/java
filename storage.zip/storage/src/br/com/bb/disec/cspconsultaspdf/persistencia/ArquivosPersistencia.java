
package br.com.bb.disec.cspconsultaspdf.persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import br.com.bb.disec.cspconsultaspdf.bean.ArquivosBean;


public class ArquivosPersistencia extends Persistencia {

	public static final String QUERY_GROUP = "dbPortal";
	
	public ArquivosPersistencia() {
    super("137");
	}
	

	public int incluirArquivo(ArquivosBean aq) throws SQLException{
		String sql = this.getQuery(QUERY_GROUP, "incluirArquivo");
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = this.getConnection();
			ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			
			ps.setInt(1, 0);
			ps.setString(2, aq.getUrl());
			ps.setLong(3, aq.getSize());
			ps.setString(4, aq.getMtc());
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
			
			if (rs.next()){
				return rs.getInt(1);
			}
			
			return 0;
		
		}
		finally {
			rs.close();
			ps.close();
			con.close();
		}		
	}
	

	
}
