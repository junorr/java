package br.com.bb.disec.cspconsultaspdf.util;

import java.text.ParseException;

import javax.swing.text.MaskFormatter;

public final class ConverterCampos {
	
		private ConverterCampos(){}
		
		public static String formatarCEP(int cep) throws ParseException {
	        MaskFormatter mf = new MaskFormatter("##.###-###");
	        mf.setValueContainsLiteralCharacters(false);
	        return mf.valueToString(cep);
	    }
	
}
