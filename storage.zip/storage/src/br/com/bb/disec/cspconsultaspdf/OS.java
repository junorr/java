package br.com.bb.disec.cspconsultaspdf;

import java.io.File;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.bb.disec.cspconsultaspdf.bean.OSBean;
import br.com.bb.disec.cspconsultaspdf.servlet.BaseServlet;

public class OS extends BaseServlet{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		@Override
		public String perform(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
			String page = "/paginas/consultaros.jsp";
			String context = null;
			try {
				context = req.getServletContext().getRealPath("/anexos/os/");
				File[] arquivos = OSBean.percorrePasta(context);
				Arrays.sort(arquivos);
				//for(int i = 0; i < arquivos.length; i++){  
			    //	  arquivos[i].getreplace("C:/kdiDisec/workspace/portalcesup/WebContent","");         
			    //  }
				req.setAttribute("arquivos", arquivos);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return page;
		}
}