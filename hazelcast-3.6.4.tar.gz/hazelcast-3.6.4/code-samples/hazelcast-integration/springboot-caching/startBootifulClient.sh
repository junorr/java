#!/bin/sh

java -cp target/lib/*:target/classes com.hazelcast.springboot.caching.BootifulClient
