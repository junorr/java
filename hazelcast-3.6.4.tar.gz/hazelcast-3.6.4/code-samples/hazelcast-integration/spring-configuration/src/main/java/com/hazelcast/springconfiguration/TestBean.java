package com.hazelcast.springconfiguration;

@SuppressWarnings("unused")
public class TestBean {

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
