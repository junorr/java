Please refer to https://rawgit.com/hazelcast/hazelcast-code-samples/master/readme.html
 for more information.
