import com.hazelcast.core.Hazelcast;

public class Test {

    public static void main(String[] args) {
        Hazelcast.newHazelcastInstance();
    }
}
