#!/bin/bash

javaHome=$JAVA_HOME

if [ -z "$javaHome" ]; then
	echo "# Invalid JAVA_HOME!"
	exit 1
fi

script=$(readlink -f $0)
dir=$(dirname $script)
cd "$dir"


if [ "$1" = "sudo" ]; then
	if [ "$3" = "-s" -o "$3" = "-k" -o "$3" = "--start" -o "$3" = "--kill" ]; then
		echo -e "$2\n" | sudo -S -E -p "" "$javaHome"/bin/java -jar syscheck.jar $3 $4 $5 $6 $7 $8 &
	else
		echo -e "$2\n" | sudo -S -E -p "" "$javaHome"/bin/java -jar syscheck.jar $3 $4 $5 $6 $7 $8
	fi
	exit 0
fi


if [ "$1" = "-s" -o "$1" = "-k" -o "$1" = "--start" -o "$1" = "--kill" ]; then
	$javaHome/bin/java -jar syscheck.jar $1 $2 $3 $4 $5 $6 &
else
	$javaHome/bin/java -jar syscheck.jar $1 $2 $3 $4 $5 $6
fi
