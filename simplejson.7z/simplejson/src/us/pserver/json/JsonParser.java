/*
 * Direitos Autorais Reservados (c) 2011 Juno Roesler
 * Contato: juno.rr@gmail.com
 * 
 * Esta biblioteca � software livre; voc� pode redistribu�-la e/ou modific�-la sob os
 * termos da Licen�a P�blica Geral Menor do GNU conforme publicada pela Free
 * Software Foundation; tanto a vers�o 2.1 da Licen�a, ou qualquer
 * vers�o posterior.
 * 
 * Esta biblioteca � distribu�da na expectativa de que seja �til, por�m, SEM
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE
 * OU ADEQUA��O A UMA FINALIDADE ESPEC�FICA. Consulte a Licen�a P�blica
 * Geral Menor do GNU para mais detalhes.
 * 
 * Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral Menor do GNU junto
 * com esta biblioteca; se n�o, acesse 
 * http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html, 
 * ou escreva para a Free Software Foundation, Inc., no
 * endere�o 59 Temple Street, Suite 330, Boston, MA 02111-1307 USA.
 */

package us.pserver.json;

/**
 *
 * @author Juno Roesler - juno.rr@gmail.com
 * @version 1.0 - 25/09/2014
 */
public class JsonParser {

  private JsonValue value;
  
  
  public JsonParser() {
    value = new JsonValue();
  }
  
  
  public JsonObject parse(String json) {
    if(json == null || json.isEmpty())
      throw new IllegalArgumentException(
          "Invalid json: "+ json);
    
    System.out.println("* parsing: "+ json);
    value.setValue(json);
    JsonObject root = new JsonObject();
    
    if(value.isValuePrimitive()) {
      System.out.println("* is primitive");
      if(value.isValueNumber()) {
        System.out.println("  is number");
        root.setValue(value.getValueAsNumber());
      }
      else if(value.isValueString()) {
        System.out.println("  is string!");
        root.setValue(value.getValueAsString());
      }
      else {
        System.out.println("  is boolean");
        root.setValue(value.getValueAsBoolean());
      }
      return root;
    }
    else if(value.isValueJsonArray()) {
      System.out.println("* is array");
      root.setValue(value.getValueAsArray());
      return root;
    }
    else if(!value.isValueJsonObject()) {
      throw new IllegalArgumentException(
          "Json is not a valid object: "+ json);
    }
    
    addElements(root, json.substring(1, json.length()-1));
    return root;
  }
  
  
  private void addElements(JsonObject obj, String str) {
    System.out.println("* addElements: "+ str);
    int ip = str.indexOf(":");
    int iv = str.indexOf(",");
    if(ip < 0) return;
    
    JsonElement el = new JsonElement();
    el.setName(str.substring(0, ip).replace("'", ""));
    
    if(iv < 0) {
      el.setValue(parse(str.substring(ip+1).replace("'", "")));
      obj.add(el);
      return;
    }
    
    el.setValue(parse(str.substring(ip+1, iv).replace("'", "")));
    obj.add(el);
    addElements(obj, str.substring(iv+1));
  }
  
  
  public static void main(String[] args) {
    String str = "{'class':'Long.class','fields':[{'integer':5}]}";
    JsonParser ps = new JsonParser();
    JsonObject p = ps.parse(str);
    System.out.println(p);
  }
  
}
