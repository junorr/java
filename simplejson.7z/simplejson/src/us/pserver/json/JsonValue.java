/*
 * Direitos Autorais Reservados (c) 2011 Juno Roesler
 * Contato: juno.rr@gmail.com
 * 
 * Esta biblioteca � software livre; voc� pode redistribu�-la e/ou modific�-la sob os
 * termos da Licen�a P�blica Geral Menor do GNU conforme publicada pela Free
 * Software Foundation; tanto a vers�o 2.1 da Licen�a, ou qualquer
 * vers�o posterior.
 * 
 * Esta biblioteca � distribu�da na expectativa de que seja �til, por�m, SEM
 * NENHUMA GARANTIA; nem mesmo a garantia impl�cita de COMERCIABILIDADE
 * OU ADEQUA��O A UMA FINALIDADE ESPEC�FICA. Consulte a Licen�a P�blica
 * Geral Menor do GNU para mais detalhes.
 * 
 * Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral Menor do GNU junto
 * com esta biblioteca; se n�o, acesse 
 * http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html, 
 * ou escreva para a Free Software Foundation, Inc., no
 * endere�o 59 Temple Street, Suite 330, Boston, MA 02111-1307 USA.
 */

package us.pserver.json;

import java.util.Objects;

/**
 *
 * @author Juno Roesler - juno.rr@gmail.com
 * @version 1.0 - 25/09/2014
 */
public class JsonValue {

  private Object value;
  
  
  public JsonValue() {
    value = null;
  }
  
  
  public JsonValue(Object value) {
    this.value = value;
  }
  
  
  public boolean isValuePrimitive() {
    return value != null
        && !value.toString().trim().startsWith("{")
        && !value.toString().trim().startsWith("[")
        && !value.toString().trim().contains(",")
        && !value.toString().trim().contains(":");
  }
  
  
  public boolean isValueNumber() {
    return getValueAsNumber() != null;
  }
  
  
  public boolean isValueString() {
    return isValuePrimitive()
        && !isValueBoolean();
  }
  
  
  public boolean isValueBoolean() {
    return value.toString().trim().equalsIgnoreCase("true")
        || value.toString().trim().equalsIgnoreCase("false");
  }
  
  
  public boolean isValueJsonObject() {
    return value != null
        && value.toString().trim().startsWith("{");
  }
  
  
  public boolean isValueJsonArray() {
    return value != null
        && value.toString().trim().startsWith("[");
  }
  
  
  public String getValueAsString() {
    if(!isValueString()) return null;
    return value.toString().trim().replace("'", "");
  }
  
  
  public Number getValueAsNumber() {
    Number n = null;
    try {
      n = Double.parseDouble(value.toString().trim());
    } catch(NumberFormatException e) {}
    return n;
  }
  
  
  public boolean getValueAsBoolean() {
    if(value == null) return false;
    return Boolean.parseBoolean(value.toString().trim().toLowerCase());
  }
  
  
  public JsonPair getValueAsObject() {
    if(value == null) return null;
    System.out.println("not null");
    if(!isValueJsonObject()) return null;
    System.out.println("is object");
    JsonPair jp = new JsonPair();
    String str = value.toString().trim().substring(1);
    str = str.substring(0, str.length() -1).trim();
    if(!str.contains(":")) return null;
    System.out.println("contains :");
    int idx = str.indexOf(":");
    jp.setName(str.substring(0, idx).replace("'", ""));
    jp.setValue(new JsonValue(str.substring(idx +1)));
    return jp;
  }


  public JsonArray getValueAsArray() {
    if(value == null) return null;
    System.out.println("not null");
    if(!isValueJsonArray()) return null;
    System.out.println("is array");
    JsonArray ja = JsonArray.fromJson(value.toString().trim());
    return ja;
  }
  
  
  public boolean isValueObjectFields() {
    return value != null
        && !isValueJsonArray()
        && !isValueJsonObject()
        && value.toString().trim().contains(",");
  }
  
  
  public JsonPair getValueAsObjectFields() {
    if(!isValueObjectFields())
      return null;
    String str = value.toString().trim();
    int id = str.indexOf(",");
    if(id < 0) return null;
    value = str.substring(0, id);
    str = str.substring(id+1);
    JsonPair jp = new JsonPair();
    if(!str.contains(":")) return null;
    id = str.indexOf(":");
    jp.setName(str.substring(0, id).replace("'", ""));
    jp.setValue(new JsonValue(str.substring(id +1)));
    return jp;
  }


  public Object getValue() {
    return value;
  }


  public JsonValue setValue(Object value) {
    this.value = value;
    return this;
  }


  @Override
  public int hashCode() {
    int hash = 7;
    hash = 79 * hash + Objects.hashCode(this.value);
    return hash;
  }


  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final JsonValue other = (JsonValue) obj;
    if (!Objects.equals(this.value, other.value)) {
      return false;
    }
    return true;
  }


  @Override
  public String toString() {
    return "JsonValue(" + "value=" + value + ')';
  }
 
  
  public static void main(String[] args) {
    String str = "[1, 2, 3, 4]";
    JsonValue jv = new JsonValue(str);
    System.out.println("* str="+ str);
    System.out.println("* jv="+ jv);
    System.out.println("* jv.isValueJsonObject? "+ jv.isValueJsonObject());
    System.out.println("* jv.getValueAsObject="+ jv.getValueAsObject());
    System.out.println("* jv.isValueJsonArray? "+ jv.isValueJsonArray());
    System.out.println("* jv.getValueAsArray="+ jv.getValueAsArray());
  }
  
}
