/*
 * Direitos Autorais Reservados (c) 2011 Juno Roesler
 * Contato: juno.rr@gmail.com
 * 
 * Esta biblioteca é software livre; você pode redistribuí-la e/ou modificá-la sob os
 * termos da Licença Pública Geral Menor do GNU conforme publicada pela Free
 * Software Foundation; tanto a versão 2.1 da Licença, ou qualquer
 * versão posterior.
 * 
 * Esta biblioteca é distribuída na expectativa de que seja útil, porém, SEM
 * NENHUMA GARANTIA; nem mesmo a garantia implícita de COMERCIABILIDADE
 * OU ADEQUAÇÃO A UMA FINALIDADE ESPECÍFICA. Consulte a Licença Pública
 * Geral Menor do GNU para mais detalhes.
 * 
 * Você deve ter recebido uma cópia da Licença Pública Geral Menor do GNU junto
 * com esta biblioteca; se não, acesse 
 * http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html, 
 * ou escreva para a Free Software Foundation, Inc., no
 * endereço 59 Temple Street, Suite 330, Boston, MA 02111-1307 USA.
 */

package us.pserver.streams;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import static us.pserver.chk.Checker.nullarg;
import static us.pserver.chk.Checker.nullarray;
import static us.pserver.chk.Checker.nullbuffer;
import static us.pserver.chk.Checker.range;

/**
 *
 * @author Juno Roesler - juno.rr@gmail.com
 * @version 1.0 - 02/07/2014
 */
public class MixedBuffer {

  public static final int BUFFER_SIZE = 1_048_576;
  
  
  private ByteBuffer buffer;
  
  private Path temp;
  
  private FileChannel channel;
  
  private OutputStream output;
  
  private InputStream input;
  
  private boolean flipped;
  
  
  public MixedBuffer() {
    buffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
    flipped = false;
  }
  
  
  public MixedBuffer(int bufferSize) {
    range(bufferSize, 1, Integer.MAX_VALUE);
    buffer = ByteBuffer.allocateDirect(bufferSize);
    flipped = false;
  }
  
  
  public int getBufferSize() {
    return buffer.capacity();
  }
  
  
  public long size() throws IOException {
    long len = buffer.position();
    if(channel != null) {
      len += channel.size();
    }
    return len;
  }
  
  
  public void reset() throws IOException {
    close();
    channel = null;
    output = null;
    input = null;
    temp = null;
  }
  
  
  public Path getTemp() {
    return temp;
  }
  
  
  private void initChannel() throws IOException {
    temp = Files.createTempFile(null, null);
    channel = FileChannel.open(temp,
        StandardOpenOption.READ, 
        StandardOpenOption.DELETE_ON_CLOSE, 
        StandardOpenOption.WRITE);
  }
  
  
  private void initInputStream() throws IOException {
    input = new InputStream() {
      @Override
      public int read() throws IOException {
        return MixedBuffer.this.read();
      }
      @Override
      public int read(byte[] bs) throws IOException {
        return MixedBuffer.this.read(bs);
      }
      @Override
      public int read(byte[] bs, int o, int l) throws IOException {
        return MixedBuffer.this.read(bs, o, l);
      }
    };//input
  }
  
  
  private void initOutputStream() throws IOException {
    output = new OutputStream() {
      @Override
      public void write(int b) throws IOException {
        MixedBuffer.this.write(b);
      }
      @Override
      public void write(byte[] bs) throws IOException {
        MixedBuffer.this.write(bs);
      }
      @Override
      public void write(byte[] bs, int o, int l) throws IOException {
        MixedBuffer.this.write(bs, o, l);
      }
    };//output
  }
  
  
  public void flush() throws IOException {
    if(buffer.position() > 0) {
      if(channel == null)
        initChannel();
      buffer.flip();
      channel.write(buffer);
      buffer.clear();
    }
  }
  
  
  public InputStream getInputStream() throws IOException {
    if(input == null) initInputStream();
    return input;
  }
  
  
  public OutputStream getOutputStream() throws IOException {
    if(output == null) initOutputStream();
    return output;
  }
  
  
  public MixedBuffer flip() throws IOException {
    if(!flipped) {
      if(channel != null) {
        flush();
        channel.position(0);
      } else {
        buffer.flip();
      }
      flipped = true;
    }
    else {
      if(channel != null) {
        channel.position(channel.size());
      } else {
        buffer.position(buffer.limit());
        buffer.limit(buffer.capacity());
      }
      flipped = false;
    }
    return this;
  }
  
  
  public void close() throws IOException {
    if(channel != null) {
      channel.close();
    }
    if(output != null) {
      output.close();
    }
    if(input != null) {
      input.close();
    }
    buffer.clear();
  }
  
  
  public void write(int b) throws IOException {
    if(flipped) flip();
    if(buffer.remaining() == 0) flush();
    buffer.put((byte) b);
  }
  
  
  public void write(byte[] bs, int offset, int length) throws IOException {
    nullarray(bs);
    range(offset, 0, bs.length -2);
    range(length, 1, bs.length - offset);
    if(flipped) flip();
    for(int i = offset; i < length; i++) {
      write(bs[i]);
    }
  }
  
  
  public void write(byte[] bs) throws IOException {
    write(bs, 0, bs.length);
  }
  
  
  public void write(ByteBuffer buf) throws IOException {
    nullbuffer(buf);
    if(flipped) flip();
    while(buf.remaining() > 0) {
      write(buf.get());
    }
  }
  
  
  public long write(InputStream in) throws IOException {
    if(flipped) flip();
    return transfer(in, getOutputStream());
  }
  
  
  public int read() throws IOException {
    if(!flipped) flip();
    if(channel != null) {
      flush();
      ByteBuffer b = ByteBuffer.allocate(1);
      channel.read(b);
      b.flip();
      return b.get();
    }
    else {
      if(buffer.position() == 0) return -1;
      return buffer.get();
    }
  }
  
  
  public int read(byte[] bs, int offset, int length) throws IOException {
    nullarray(bs);
    range(offset, 0, bs.length -2);
    range(length, 1, bs.length - offset);
    
    if(!flipped) flip();
    if(channel != null) {
      ByteBuffer b = ByteBuffer.allocate(length);
      int read = channel.read(b);
      if(read <= 0) return read;
      b.flip();
      b.get(bs, offset, read);
      return read;
    }
    else {
      if(buffer.remaining() == 0) return -1;
      if(length > buffer.remaining())
        length = buffer.remaining();
      buffer.get(bs, offset, length);
      return length;
    }
  }
  
  
  public int read(byte[] bs) throws IOException {
    nullarray(bs);
    return read(bs, 0, bs.length);
  }
  
  
  public int read(ByteBuffer buf) throws IOException {
    nullbuffer(buf);
    if(!flipped) flip();
    byte[] bs = new byte[buf.limit()];
    int read = read(bs);
    if(read <= 0) return read;
    buf.put(bs, 0, read);
    return read;
  }
  
  
  public long read(OutputStream out) throws IOException {
    if(!flipped) flip();
    return transfer(getInputStream(), out);
  }
  
  
  public static long transfer(InputStream is, OutputStream os) throws IOException {
    nullarg(InputStream.class, is);
    nullarg(OutputStream.class, os);
    long total = 0;
    byte[] bs = new byte[8192];
    int read = 0;
    while((read = is.read(bs)) > 0) {
      total += read;
      os.write(bs, 0, read);
    }
    os.flush();
    return total;
  }
  
}
