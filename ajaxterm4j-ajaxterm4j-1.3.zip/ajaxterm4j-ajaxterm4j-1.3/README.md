Ajaxterm4j
==========

Terminal emulator inside browser, with the server-side implementation in Java. See [the website](http://ajaxterm4j.kohsuke.org/) for more details.
