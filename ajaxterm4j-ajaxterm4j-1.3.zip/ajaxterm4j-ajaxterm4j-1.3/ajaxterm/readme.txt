This version is based on Ajaxterm 0.10
