package org.littleshoot.proxy;

/**
 * Enumeration of transport protocols supported by LittleProxy.
 */
public enum TransportProtocol {
    TCP, UDT
}