-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 172.29.14.107    Database: mstNovo
-- ------------------------------------------------------
-- Server version	5.5.29-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mstNovo`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mstNovo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mstNovo`;

--
-- Table structure for table `DEPE_JRDT`
--

DROP TABLE IF EXISTS `DEPE_JRDT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEPE_JRDT` (
  `CD_UOR` int(10) unsigned NOT NULL,
  `CD_PRF` int(10) unsigned DEFAULT NULL,
  `CD_SBDD` int(10) unsigned DEFAULT NULL,
  `NM_UOR_RED` varchar(45) DEFAULT NULL,
  `SG_UF` varchar(2) DEFAULT NULL,
  `CD_TIP_UOR` int(10) unsigned DEFAULT NULL,
  `NM_TIP_UOR_RED` varchar(45) DEFAULT NULL,
  `CD_NIV` int(10) unsigned DEFAULT NULL,
  `CD_EST_FCN` int(10) unsigned DEFAULT NULL,
  `NM_EST_FCN` varchar(45) DEFAULT NULL,
  `CD_PRF_SBDT_HRQO` int(10) unsigned DEFAULT NULL,
  `NM_SBDT_HRQO` varchar(45) DEFAULT NULL,
  `CD_PRF_SPCA` int(10) unsigned DEFAULT NULL,
  `NM_SPCA` varchar(45) DEFAULT NULL,
  `CD_PRF_GEREV` int(10) unsigned DEFAULT NULL,
  `NM_GEREV` varchar(45) DEFAULT NULL,
  `CD_PRF_SERET` int(10) unsigned DEFAULT NULL,
  `NM_SERET` varchar(45) DEFAULT NULL,
  `CD_PRF_CSL_CENOP_COMPRAS_CTR` int(10) unsigned DEFAULT NULL,
  `NM_CSL_CENOP_COMPRAS` varchar(45) DEFAULT NULL,
  `CD_PRF_CSO_CENOP_OPER` int(10) unsigned DEFAULT NULL,
  `NM_CSO_CENOP_OPER` varchar(45) DEFAULT NULL,
  `CD_PRF_CSL_CENOP_AVAL` int(10) unsigned DEFAULT NULL,
  `NM_CSL_CENOP_AVAL` varchar(45) DEFAULT NULL,
  `CD_PRF_CSL_GENOP` int(10) unsigned DEFAULT NULL,
  `NM_CSL_GENOP` varchar(45) DEFAULT NULL,
  `CD_PRF_CSL_GENOP_ALMOX` int(10) unsigned DEFAULT NULL,
  `NM_CSL_GENOP_ALMOX` varchar(45) DEFAULT NULL,
  `CD_PRF_PEE` int(10) unsigned DEFAULT NULL,
  `NM_PEE` varchar(45) DEFAULT NULL,
  `CD_PRF_SOP` int(10) unsigned DEFAULT NULL,
  `NM_SOP` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`CD_UOR`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `IORF002E`
--

DROP TABLE IF EXISTS `IORF002E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IORF002E` (
  `CD_IOR` mediumint(9) unsigned DEFAULT NULL COMMENT 'Código da Instituição Organizacional (IOR)',
  `CD_AQTT` smallint(3) unsigned NOT NULL COMMENT 'Código do Item de Arquitetura',
  `CD_NTZ_AQTT` tinyint(1) unsigned NOT NULL COMMENT 'Código da Natureza do Item de Arquitetura',
  `NM_AQTT_RED` varchar(40) NOT NULL COMMENT 'Nome do Item de Arquitetura',
  `NM_AQTT_CMPL` varchar(65) NOT NULL COMMENT 'Nome Completo do Item de Arquitetura',
  `DT_INI_VAL` date DEFAULT NULL COMMENT 'Data de Início de Validade',
  `DT_FIM_VAL` date DEFAULT NULL COMMENT 'Data de Fim de Validade',
  `DT_ATL` date DEFAULT NULL COMMENT 'Data de Atualização',
  `HORA_ATL` time DEFAULT NULL COMMENT 'Horário de Atualização',
  `MTC_RSP_ATL` char(8) NOT NULL COMMENT 'Matricula do Responsável pela Atualização',
  PRIMARY KEY (`CD_AQTT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSTF500G`
--

DROP TABLE IF EXISTS `MSTF500G`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSTF500G` (
  `CD_UOR` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `CD_IOR` mediumint(9) unsigned NOT NULL,
  `NM_UOR_RED` varchar(20) NOT NULL,
  `NM_UOR_CMPL` varchar(50) DEFAULT NULL,
  `DT_CRIC` date DEFAULT NULL,
  `DT_ENC` date DEFAULT NULL,
  `DT_ATL` date DEFAULT NULL,
  `HH_ATL` time DEFAULT NULL,
  `CD_RSP_ATL` char(8) DEFAULT NULL,
  `CD_TIPO` smallint(4) unsigned DEFAULT NULL,
  `CD_TIP_UOR` tinyint(1) unsigned DEFAULT NULL,
  `SIT_FUNC` tinyint(1) unsigned DEFAULT NULL,
  `MCI_DEP` int(9) unsigned DEFAULT NULL,
  `CNPJ` bigint(14) unsigned DEFAULT NULL,
  `SG_UOR` varchar(10) DEFAULT NULL,
  `IND_RST_ACSS` tinyint(1) unsigned DEFAULT NULL,
  `IND_PION_MUNC` tinyint(1) unsigned DEFAULT NULL,
  `DT_INI_ATV` date DEFAULT NULL,
  `DT_PRV_ENC` date DEFAULT NULL,
  `MCI_LOCAL` int(9) unsigned DEFAULT NULL,
  `PRF_DEP` smallint(4) unsigned zerofill DEFAULT NULL,
  `SB_DEP` tinyint(2) unsigned zerofill DEFAULT NULL,
  `DG_VERF` char(1) DEFAULT NULL,
  `END_TMP_01` varchar(249) DEFAULT NULL,
  `END_TMP_02` varchar(130) DEFAULT NULL,
  `IND_NAC_END` char(1) DEFAULT NULL,
  `CD_LTD` bigint(20) DEFAULT NULL,
  `CD_LGTE` bigint(20) DEFAULT NULL,
  `CD_TP_UOR_VINC` tinyint(2) unsigned DEFAULT NULL,
  `UOR_HRQO` mediumint(9) unsigned DEFAULT NULL,
  `CD_OUTORG` smallint(4) unsigned DEFAULT NULL,
  `CD_SIT_OUTORG` tinyint(1) unsigned DEFAULT NULL,
  `DT_AUTZ_OUTORG` date DEFAULT NULL,
  `DT_VENC_OUTORG` date DEFAULT NULL,
  `CD_TIP_AGRUP` smallint(4) unsigned DEFAULT NULL,
  `CD_NAT_AGRUP` tinyint(2) unsigned DEFAULT NULL,
  `CD_NIV` tinyint(2) unsigned DEFAULT NULL,
  `DT_NIV` date DEFAULT NULL,
  `CD_PILAR` tinyint(1) unsigned DEFAULT NULL,
  `CD_PERFIL` tinyint(1) unsigned DEFAULT NULL,
  `DT_INI_AUT_CONT` date DEFAULT NULL,
  `DT_FIM_AUT_CONT` date DEFAULT NULL,
  `CD_CAM_COMPE` smallint(4) unsigned DEFAULT NULL,
  `CD_COMPE` tinyint(2) unsigned DEFAULT NULL,
  `IND_ESP_ESTILO` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`CD_UOR`),
  KEY `NDX_PRF_SB` (`PRF_DEP`,`SB_DEP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSTF501E`
--

DROP TABLE IF EXISTS `MSTF501E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSTF501E` (
  `CD_UOR_JRDD` mediumint(9) unsigned NOT NULL,
  `CD_JRDC` mediumint(6) unsigned NOT NULL,
  `CD_IOR_UOR_JRDD` smallint(5) unsigned DEFAULT NULL,
  `TIP_UOR_JRDD` smallint(4) unsigned DEFAULT NULL,
  `SIT_FUNC_UOR_JRDD` tinyint(1) unsigned DEFAULT NULL,
  `CD_NAT_JRDC` tinyint(1) unsigned DEFAULT NULL,
  `CD_CAT_JRDC` tinyint(2) unsigned DEFAULT NULL,
  `CD_UOR_JRDT` mediumint(9) unsigned NOT NULL,
  `CD_IOR_UOR_JRDT` smallint(5) unsigned DEFAULT NULL,
  `TIP_UOR_JRDT` int(10) unsigned DEFAULT NULL,
  `SIT_FUNC_UOR_JRDT` tinyint(1) unsigned DEFAULT NULL,
  `ITVL_NVL_HRQO` tinyint(3) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MSTF505E`
--

DROP TABLE IF EXISTS `MSTF505E`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MSTF505E` (
  `CD_JRDC` mediumint(5) unsigned NOT NULL,
  `CD_NTZ_JRDC` tinyint(2) unsigned DEFAULT NULL,
  `CD_CAT_JRDC` tinyint(2) unsigned DEFAULT NULL,
  `CD_IOR` mediumint(5) unsigned DEFAULT NULL,
  `NM_JRDC` varchar(50) DEFAULT NULL,
  `DCR_JRDC` varchar(200) DEFAULT NULL,
  `DT_CRI_JRDC` date DEFAULT NULL,
  `DT_FIM_JRDC` date DEFAULT NULL,
  `SIT_JRDC` tinyint(1) unsigned DEFAULT NULL COMMENT '1 = Ativo; 0 = Inativo',
  PRIMARY KEY (`CD_JRDC`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `PRF_PSO_GAT`
--

DROP TABLE IF EXISTS `PRF_PSO_GAT`;
/*!50001 DROP VIEW IF EXISTS `PRF_PSO_GAT`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `PRF_PSO_GAT` AS SELECT 
 1 AS `cd_prf`,
 1 AS `cd_sbdd`,
 1 AS `prf_orig`,
 1 AS `sbdd_orig`,
 1 AS `campo5`,
 1 AS `depe_hrqo`,
 1 AS `campo7`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `PRF_PSO_GAT_sub`
--

DROP TABLE IF EXISTS `PRF_PSO_GAT_sub`;
/*!50001 DROP VIEW IF EXISTS `PRF_PSO_GAT_sub`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `PRF_PSO_GAT_sub` AS SELECT 
 1 AS `CD_PRF`,
 1 AS `CD_SBDD`,
 1 AS `depe_hrqo`,
 1 AS `nm_hrqo`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `PSO`
--

DROP TABLE IF EXISTS `PSO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PSO` (
  `CD_UOR` mediumint(9) unsigned NOT NULL DEFAULT '0' COMMENT 'Código da UOR',
  `CD_PRF` smallint(4) unsigned zerofill DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `CD_SBDD` tinyint(2) unsigned zerofill DEFAULT '00' COMMENT 'Codigo da Subordinada',
  `NM_UOR_RED` varchar(20) NOT NULL COMMENT 'Nome da UOR Reduzido',
  `NM_UOR_CMPL` varchar(50) DEFAULT NULL COMMENT 'Nome da UOR Completo',
  `SG_UF` char(2) DEFAULT NULL,
  `CD_MUN` mediumint(5) unsigned DEFAULT NULL,
  `NM_MUN` varchar(60) DEFAULT NULL,
  `CD_TIP_UOR` smallint(4) unsigned DEFAULT NULL COMMENT 'Codigo da tipologia do UOR',
  `CD_EST_FCN` tinyint(1) unsigned DEFAULT NULL COMMENT 'Codigo do Status de funcionamento',
  `UOR_HRQO` mediumint(9) unsigned DEFAULT NULL COMMENT 'Código do UOR Hierarquica',
  `PRF_HRQO` smallint(4) unsigned zerofill DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `NM_HRQO` varchar(20) NOT NULL COMMENT 'Nome da UOR Reduzido',
  `CD_NIV` tinyint(2) unsigned DEFAULT NULL COMMENT 'Código do Nível',
  `CD_UOR_SPCA` mediumint(9) unsigned DEFAULT NULL COMMENT 'Código do UOR Hierarquica',
  `CD_PRF_SPCA` smallint(4) unsigned zerofill DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `NM_SPCA` varchar(20) NOT NULL COMMENT 'Nome da UOR Reduzido',
  `MTC_GER_PSO` varchar(2) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `MTC_GER_REDE` char(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `PrfSop1_sub`
--

DROP TABLE IF EXISTS `PrfSop1_sub`;
/*!50001 DROP VIEW IF EXISTS `PrfSop1_sub`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `PrfSop1_sub` AS SELECT 
 1 AS `CD_PRF`,
 1 AS `CD_SBDD`,
 1 AS `depe_hrqo`,
 1 AS `nm_hrqo`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cat_jrdc`
--

DROP TABLE IF EXISTS `cat_jrdc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_jrdc` (
  `CD_CAT_JRDC` tinyint(2) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Codigo da Categoria das Jurisdiçoes.',
  `NM_CAT_JRDC` varchar(20) NOT NULL COMMENT 'Descriçao da Categoria das Jurisdiçoes.',
  PRIMARY KEY (`CD_CAT_JRDC`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='Atualizada MANUALMENTE.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `depe`
--

DROP TABLE IF EXISTS `depe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depe` (
  `CD_UOR` mediumint(9) unsigned NOT NULL DEFAULT '0' COMMENT 'Código da UOR',
  `CD_IOR` mediumint(9) unsigned NOT NULL COMMENT 'Código da IOR',
  `NM_UOR_RED` varchar(20) NOT NULL COMMENT 'Nome da UOR Reduzido',
  `NM_UOR_CMPL` varchar(50) DEFAULT NULL COMMENT 'Nome da UOR Completo',
  `DT_CRIC` date DEFAULT NULL COMMENT 'Data de Criação',
  `DT_ENC` date DEFAULT NULL COMMENT 'Data de Encerramento',
  `DT_ATL` date DEFAULT NULL COMMENT 'Data de Atualização',
  `HH_ATL` time DEFAULT NULL COMMENT 'Horário de Atualização',
  `MTC_RSP_ATL` char(8) DEFAULT NULL COMMENT 'Matricula do Responsável pela Atualização',
  `CD_TIP_UOR` smallint(4) unsigned DEFAULT NULL COMMENT 'Codigo da tipologia do UOR',
  `CD_EST_FCN` tinyint(1) unsigned DEFAULT NULL COMMENT 'Codigo do Status de funcionamento',
  `MCI_DEP` int(9) unsigned DEFAULT NULL COMMENT 'MCI da dependencia',
  `CNPJ` int(6) unsigned DEFAULT NULL COMMENT 'CNPJ da dependencia',
  `SG_UOR` varchar(10) DEFAULT NULL COMMENT 'Sigla do UOR (nome da divisao, por ex.)',
  `IND_RST_ACSS` tinyint(1) unsigned DEFAULT NULL COMMENT 'Indicador de Restrição de Acesso',
  `IND_PION_MUN` tinyint(1) unsigned DEFAULT NULL COMMENT 'Indicador de Agencia Pioneira de Município',
  `DT_INI_ATV` date DEFAULT NULL COMMENT 'Data de Início de Atividades',
  `DT_PRV_ENC` date DEFAULT NULL COMMENT 'Data Prevista de Encerramento',
  `MCI_LCL` int(9) unsigned DEFAULT '0' COMMENT 'MCI de Localização',
  `CD_PRF` smallint(4) unsigned zerofill DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `CD_SBDD` tinyint(2) unsigned zerofill DEFAULT '00' COMMENT 'Codigo da Subordinada',
  `DG_CVV` char(1) DEFAULT NULL COMMENT 'Dígito Verificador do Prefixo',
  `IND_NAC_END` char(1) DEFAULT NULL COMMENT 'Indicador de Nacionalidade do Endereço',
  `CD_LTD` bigint(20) DEFAULT NULL COMMENT 'Latitude',
  `CD_LGTE` bigint(20) DEFAULT NULL COMMENT 'Longitude',
  `CD_TIP_UOR_HRQO` tinyint(2) unsigned DEFAULT NULL COMMENT 'Código do Tipo UOR Hierarquica',
  `UOR_HRQO` mediumint(9) unsigned DEFAULT NULL COMMENT 'Código do UOR Hierarquica',
  `CD_OUTG` smallint(4) unsigned DEFAULT NULL COMMENT 'Código da Outorga\r\n',
  `CD_SIT_OUTG` tinyint(1) unsigned DEFAULT NULL COMMENT 'Código da Situação da Outorga',
  `DT_AUTZ_OUTG` date DEFAULT NULL COMMENT 'Data de Autorização da Outorga',
  `DT_VENC_OUTG` date DEFAULT NULL COMMENT 'Data de Vencimento da Outorga',
  `CD_TIP_AGPT` smallint(4) unsigned DEFAULT NULL COMMENT 'Código do Tipo de Agrupamento',
  `CD_NAT_AGPT` tinyint(2) unsigned DEFAULT NULL COMMENT 'Código da Natureza do Agrupamento',
  `CD_NIV` tinyint(2) unsigned DEFAULT NULL COMMENT 'Código do Nível',
  `DT_NIV` date DEFAULT NULL COMMENT 'Data do Nível',
  `CD_PILAR` tinyint(1) unsigned DEFAULT NULL COMMENT 'Código do Pilar',
  `CD_PRFL` tinyint(1) unsigned DEFAULT NULL COMMENT 'Código do Perfil',
  `DT_INI_AUT_CONT` date DEFAULT NULL COMMENT 'Data de Início da Autonomia Contábil',
  `DT_FIM_AUT_CONT` date DEFAULT NULL COMMENT 'Data de Fim da Autonomia Contábil',
  `CD_CAM_COMPE` smallint(4) unsigned DEFAULT NULL COMMENT 'Código da Câmara de Compensação',
  `CD_COMPE` tinyint(2) unsigned DEFAULT NULL COMMENT 'Código COMPE',
  `IND_ESP_ESTILO` tinyint(1) unsigned DEFAULT NULL COMMENT 'Indicador de Espaço Estilo',
  PRIMARY KEY (`CD_UOR`),
  KEY `NDX_PRF_SB` (`CD_PRF`,`CD_SBDD`) USING BTREE,
  KEY `NDX_SUPER` (`UOR_HRQO`),
  KEY `NDX_PRF` (`CD_PRF`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `depe_end`
--

DROP TABLE IF EXISTS `depe_end`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depe_end` (
  `CD_UOR` mediumint(9) unsigned NOT NULL,
  `CD_PAIS` tinyint(1) unsigned NOT NULL,
  `CD_CEP` varchar(15) DEFAULT NULL,
  `END_UOR` varchar(60) DEFAULT NULL,
  `CMPT_END` varchar(60) DEFAULT NULL,
  `REF_END` varchar(60) DEFAULT NULL,
  `NM_BAI` varchar(60) DEFAULT NULL,
  `CD_MUN` mediumint(5) unsigned DEFAULT NULL,
  `NM_MUN` varchar(60) DEFAULT NULL,
  `SG_UF` char(2) DEFAULT NULL,
  PRIMARY KEY (`CD_UOR`),
  KEY `NDX_CEP` (`CD_CEP`),
  KEY `NDX_CD_MUN` (`CD_MUN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `depe_hrqo`
--

DROP TABLE IF EXISTS `depe_hrqo`;
/*!50001 DROP VIEW IF EXISTS `depe_hrqo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `depe_hrqo` AS SELECT 
 1 AS `CD_UOR`,
 1 AS `CD_PRF`,
 1 AS `NM_UOR`,
 1 AS `CD_UOR_HRQO`,
 1 AS `CD_PRF_HRQO`,
 1 AS `NM_UOR_HRQO`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `depe_hrqo_uf`
--

DROP TABLE IF EXISTS `depe_hrqo_uf`;
/*!50001 DROP VIEW IF EXISTS `depe_hrqo_uf`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `depe_hrqo_uf` AS SELECT 
 1 AS `CD_UOR`,
 1 AS `CD_PRF`,
 1 AS `NM_UOR`,
 1 AS `CD_UOR_HRQO`,
 1 AS `CD_PRF_HRQO`,
 1 AS `NM_UOR_HRQO`,
 1 AS `SG_UF_UOR`,
 1 AS `SG_UF_UOR_HRQO`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `depe_jrdc`
--

DROP TABLE IF EXISTS `depe_jrdc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depe_jrdc` (
  `CD_UOR_JRDD` mediumint(9) unsigned NOT NULL COMMENT 'Código da UOR Jurisdicionada ',
  `CD_JRDC` mediumint(6) unsigned NOT NULL COMMENT 'Código da Jurisdição',
  `CD_NAT_JRDC` tinyint(1) unsigned NOT NULL COMMENT 'Código da Natureza da Jurisdição',
  `CD_CAT_JRDC` tinyint(2) unsigned NOT NULL COMMENT 'Código da Categoria da Jurisdição\r\n	',
  `CD_UOR_JRDT` mediumint(9) unsigned NOT NULL COMMENT 'Código da UOR Jurisdicionante ',
  `ITVL_NVL_HRQO` tinyint(3) unsigned NOT NULL COMMENT 'Número do Intervalo do Nível Hierárquico',
  PRIMARY KEY (`CD_UOR_JRDD`,`CD_JRDC`),
  KEY `NDX_JRDD` (`CD_UOR_JRDD`),
  KEY `NDX_JRDC_JRDT` (`CD_JRDC`,`CD_UOR_JRDT`),
  KEY `NDX_JRDT` (`CD_UOR_JRDT`) USING BTREE,
  KEY `NDX_JRDC` (`CD_JRDC`) USING BTREE,
  KEY `NDX_JRDC_JRDD_JRDT` (`CD_JRDC`,`CD_UOR_JRDD`,`CD_UOR_JRDT`),
  KEY `NDX_JRDD_JRDC_JRDT` (`CD_UOR_JRDD`,`CD_JRDC`,`CD_UOR_JRDT`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `depe_jrdc_genop`
--

DROP TABLE IF EXISTS `depe_jrdc_genop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depe_jrdc_genop` (
  `cd_prf_depe` smallint(4) unsigned zerofill NOT NULL DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `cd_prf_depe_jrdt` smallint(4) unsigned zerofill NOT NULL DEFAULT '0000' COMMENT 'Codigo do Prefixo',
  `nm_depe` varchar(50) DEFAULT NULL COMMENT 'Nome da UOR Completo',
  PRIMARY KEY (`cd_prf_depe`,`cd_prf_depe_jrdt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `depe_jrdc_hrqo`
--

DROP TABLE IF EXISTS `depe_jrdc_hrqo`;
/*!50001 DROP VIEW IF EXISTS `depe_jrdc_hrqo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `depe_jrdc_hrqo` AS SELECT 
 1 AS `CD_UOR`,
 1 AS `CD_PRF`,
 1 AS `NM_UOR_RED`,
 1 AS `CD_PRF_HRQO`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `depe_tip_uor_hrqo`
--

DROP TABLE IF EXISTS `depe_tip_uor_hrqo`;
/*!50001 DROP VIEW IF EXISTS `depe_tip_uor_hrqo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `depe_tip_uor_hrqo` AS SELECT 
 1 AS `CD_UOR`,
 1 AS `UOR_HRQO`,
 1 AS `CD_PRF`,
 1 AS `NM_UOR_RED`,
 1 AS `cd_tip_uor`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `est_fcn_uor`
--

DROP TABLE IF EXISTS `est_fcn_uor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `est_fcn_uor` (
  `CD_EST_FCN` tinyint(2) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Codigo do Status de funcionamento',
  `NM_EST_FCN` varchar(30) NOT NULL COMMENT 'Status de funcionamento.',
  PRIMARY KEY (`CD_EST_FCN`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='Atualizada MANUALMENTE.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jrdc`
--

DROP TABLE IF EXISTS `jrdc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jrdc` (
  `CD_JRDC` mediumint(5) unsigned NOT NULL,
  `CD_NTZ_JRDC` tinyint(2) unsigned DEFAULT NULL,
  `CD_CAT_JRDC` tinyint(2) unsigned DEFAULT NULL,
  `NM_JRDC` varchar(50) DEFAULT NULL,
  `DCR_JRDC` varchar(200) DEFAULT NULL,
  `DT_CRI_JRDC` date DEFAULT NULL,
  `DT_FIM_JRDC` date DEFAULT NULL,
  `CD_IOR` mediumint(5) unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mun`
--

DROP TABLE IF EXISTS `mun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mun` (
  `CD_MUN` mediumint(5) unsigned DEFAULT NULL COMMENT 'Codigo BB do municipio.',
  `NM_MUN` varchar(60) DEFAULT NULL COMMENT 'Nome do municipio.',
  `SG_UF` char(2) DEFAULT NULL COMMENT 'Estado do municipio.',
  `CD_PAIS` tinyint(2) unsigned DEFAULT NULL COMMENT 'Codigo do pais.',
  `ID_MUN` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID_MUN`),
  KEY `NDX_SG_UF` (`SG_UF`) USING BTREE,
  KEY `NDX_CD_MUN` (`CD_MUN`)
) ENGINE=MyISAM AUTO_INCREMENT=4157 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tip_uor`
--

DROP TABLE IF EXISTS `tip_uor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tip_uor` (
  `CD_TIP_UOR` smallint(3) unsigned NOT NULL COMMENT 'Código do Item de Arquitetura',
  `CD_NTZ_TIP_UOR` tinyint(1) unsigned NOT NULL COMMENT 'Código da Natureza do Item de Arquitetura',
  `NM_TIP_UOR_RED` varchar(40) NOT NULL COMMENT 'Nome do Item de Arquitetura',
  `NM_TIP_UOR_CMPL` varchar(65) NOT NULL COMMENT 'Nome Completo do Item de Arquitetura',
  `DT_INI_VAL` date DEFAULT NULL COMMENT 'Data de Início de Validade',
  `DT_FIM_VAL` date DEFAULT NULL COMMENT 'Data de Fim de Validade',
  `DT_ATL` date DEFAULT NULL COMMENT 'Data de Atualização',
  `HORA_ATL` time DEFAULT NULL COMMENT 'Horário de Atualização',
  `MTC_RSP_ATL` char(8) NOT NULL COMMENT 'Matricula do Responsável pela Atualização',
  PRIMARY KEY (`CD_TIP_UOR`),
  KEY `NDX_NTZ_TIP` (`CD_NTZ_TIP_UOR`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uf_rgao`
--

DROP TABLE IF EXISTS `uf_rgao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uf_rgao` (
  `SG_UF` char(2) NOT NULL,
  `NM_RGAO` varchar(15) NOT NULL,
  PRIMARY KEY (`SG_UF`),
  KEY `NDX_RGAO` (`NM_RGAO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `uor_jrdd_jrdt`
--

DROP TABLE IF EXISTS `uor_jrdd_jrdt`;
/*!50001 DROP VIEW IF EXISTS `uor_jrdd_jrdt`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `uor_jrdd_jrdt` AS SELECT 
 1 AS `CD_UOR_JRDD`,
 1 AS `CD_PRF`,
 1 AS `CD_SBDD`,
 1 AS `NM_UOR_RED`,
 1 AS `CD_UOR_JRDT`,
 1 AS `CD_TIP_UOR`,
 1 AS `NM_TIP_UOR_RED`*/;
SET character_set_client = @saved_cs_client;

--
-- Current Database: `intranet`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `intranet` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `intranet`;

--
-- Table structure for table `agpt_acss`
--

DROP TABLE IF EXISTS `agpt_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agpt_acss` (
  `cd_agpt_acss` int(11) NOT NULL DEFAULT '0',
  `nm_cls_mtd_depe` varchar(100) DEFAULT NULL,
  `nm_cls_mtd_crg` varchar(100) DEFAULT NULL,
  `nm_cls_mtd_fun` varchar(100) DEFAULT NULL,
  `tx_desc` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`cd_agpt_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asnt_ctu`
--

DROP TABLE IF EXISTS `asnt_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asnt_ctu` (
  `cd_asnt_ctu` int(11) NOT NULL DEFAULT '0',
  `nm_asnt` varchar(45) NOT NULL,
  `cd_tp_ctu` int(10) unsigned NOT NULL,
  PRIMARY KEY (`cd_asnt_ctu`),
  KEY `ndx_tp_ctu` (`cd_tp_ctu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `base_fon_ctu`
--

DROP TABLE IF EXISTS `base_fon_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_fon_ctu` (
  `CD_FON` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Codigo Fonetico',
  `CHAVE` varchar(10) NOT NULL COMMENT 'Chave Fonetico',
  PRIMARY KEY (`CD_FON`,`CHAVE`)
) ENGINE=MyISAM AUTO_INCREMENT=771 DEFAULT CHARSET=latin1 COMMENT='Base fonetica dos conteudos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ctu_fon`
--

DROP TABLE IF EXISTS `ctu_fon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ctu_fon` (
  `CD_CTU` int(10) unsigned NOT NULL,
  `CD_FON` int(10) unsigned NOT NULL,
  PRIMARY KEY (`CD_CTU`,`CD_FON`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Relaciona os conteudos com as chaves foneticas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `ctu_grp`
--

DROP TABLE IF EXISTS `ctu_grp`;
/*!50001 DROP VIEW IF EXISTS `ctu_grp`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ctu_grp` AS SELECT 
 1 AS `cd_ctu`,
 1 AS `cd_gr_acss`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `dcr_ctu`
--

DROP TABLE IF EXISTS `dcr_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dcr_ctu` (
  `cd_ctu` int(10) unsigned NOT NULL DEFAULT '0',
  `cd_ctu_pai` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Relaciona se o cd_ctu esta vinculado a outro',
  `nm_ctu` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `cd_tp_ctu` int(11) DEFAULT NULL,
  `tx_url_ctu` varchar(700) CHARACTER SET latin1 NOT NULL,
  `cd_sit_ctu` int(11) DEFAULT NULL,
  `dt_inc_ctu` date DEFAULT NULL,
  `dt_fim_ctu` date DEFAULT NULL,
  `dt_atl_ctu` datetime DEFAULT NULL,
  `cd_agpt_acss` int(11) DEFAULT NULL,
  `cd_clsc_inf` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `nm_fon` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `nm_rsp` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `cd_tran` varchar(8) CHARACTER SET latin1 DEFAULT NULL,
  `cd_depe_ctu` int(11) DEFAULT NULL,
  `cd_asnt_ctu` int(11) DEFAULT NULL,
  `cd_perc` int(11) DEFAULT NULL,
  `in_envo_msg_gst` int(11) DEFAULT NULL,
  `cd_emai_gst` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cd_fun_rsp` varchar(8) CHARACTER SET latin1 DEFAULT NULL,
  `in_pag_ppl` enum('Y','N') CHARACTER SET latin1 DEFAULT NULL,
  `tx_url_arq_ajd` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `img` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `cd_url` tinyint(3) unsigned NOT NULL,
  `is_log` tinyint(1) NOT NULL DEFAULT '0',
  `in_dtq` tinyint(1) unsigned NOT NULL,
  `dt_dtq` date NOT NULL,
  `icone_app` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT 'app_00',
  PRIMARY KEY (`cd_ctu`),
  UNIQUE KEY `tx_url_ctu_UNIQUE` (`tx_url_ctu`),
  KEY `NDX_CD_CTU_PAI` (`cd_ctu_pai`,`cd_ctu`),
  KEY `NDX_TP_CTU` (`cd_tp_ctu`),
  KEY `NDX_ASNT_CTU` (`cd_asnt_ctu`),
  KEY `FK_dcr_ctu_sit_ctu` (`cd_sit_ctu`),
  KEY `FK_dcr_ctu_perc` (`cd_perc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dcr_ctu_bkp`
--

DROP TABLE IF EXISTS `dcr_ctu_bkp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dcr_ctu_bkp` (
  `cd_ctu` int(10) unsigned NOT NULL DEFAULT '0',
  `cd_ctu_pai` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Relaciona se o cd_ctu esta vinculado a outro',
  `nm_ctu` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `cd_tp_ctu` int(11) DEFAULT NULL,
  `tx_url_ctu` varchar(700) CHARACTER SET latin1 DEFAULT NULL,
  `cd_sit_ctu` int(11) DEFAULT NULL,
  `dt_inc_ctu` date DEFAULT NULL,
  `dt_fim_ctu` date DEFAULT NULL,
  `dt_atl_ctu` datetime DEFAULT NULL,
  `cd_agpt_acss` int(11) DEFAULT NULL,
  `cd_clsc_inf` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `nm_fon` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `nm_rsp` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `cd_tran` varchar(8) CHARACTER SET latin1 DEFAULT NULL,
  `cd_depe_ctu` int(11) DEFAULT NULL,
  `cd_asnt_ctu` int(11) DEFAULT NULL,
  `cd_perc` int(11) DEFAULT NULL,
  `in_envo_msg_gst` int(11) DEFAULT NULL,
  `cd_emai_gst` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `cd_fun_rsp` varchar(8) CHARACTER SET latin1 DEFAULT NULL,
  `in_pag_ppl` enum('Y','N') CHARACTER SET latin1 DEFAULT NULL,
  `tx_url_arq_ajd` varchar(250) CHARACTER SET latin1 DEFAULT NULL,
  `img` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `cd_url` tinyint(3) unsigned NOT NULL,
  `is_log` tinyint(1) NOT NULL DEFAULT '0',
  `in_dtq` tinyint(1) unsigned NOT NULL,
  `dt_dtq` date NOT NULL,
  PRIMARY KEY (`cd_ctu`),
  KEY `NDX_CD_CTU_PAI` (`cd_ctu_pai`,`cd_ctu`),
  KEY `NDX_TP_CTU` (`cd_tp_ctu`),
  KEY `NDX_ASNT_CTU` (`cd_asnt_ctu`),
  KEY `FK_dcr_ctu_sit_ctu` (`cd_sit_ctu`),
  KEY `FK_dcr_ctu_perc` (`cd_perc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dcr_ctu_img`
--

DROP TABLE IF EXISTS `dcr_ctu_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dcr_ctu_img` (
  `cd_ctu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img_ctu` varchar(100) NOT NULL,
  PRIMARY KEY (`cd_ctu`)
) ENGINE=MyISAM AUTO_INCREMENT=806 DEFAULT CHARSET=latin1 COMMENT='Relaciona as logos das aplicacoes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dfnc_ctu`
--

DROP TABLE IF EXISTS `dfnc_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dfnc_ctu` (
  `CD_CTU` int(10) unsigned NOT NULL,
  `CD_DFNC_CTU` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NM_DFNC_CTU` varchar(200) NOT NULL,
  PRIMARY KEY (`CD_CTU`,`CD_DFNC_CTU`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Relaciona os conteudos e suas definicoes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gr_acss`
--

DROP TABLE IF EXISTS `gr_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gr_acss` (
  `cd_acss` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nm_acss` varchar(50) NOT NULL,
  `dcr_acss` varchar(100) NOT NULL,
  PRIMARY KEY (`cd_acss`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='Relaciona os grupos de acessos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lista`
--

DROP TABLE IF EXISTS `lista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lista` (
  `NOME` varchar(300) NOT NULL,
  `TIP_ASNT` tinyint(3) unsigned NOT NULL,
  `URL` varchar(300) NOT NULL,
  `CD_CTU` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`CD_CTU`)
) ENGINE=MyISAM AUTO_INCREMENT=20183 DEFAULT CHARSET=latin1 PACK_KEYS=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `cd_log` int(11) NOT NULL AUTO_INCREMENT,
  `cd_ctu` int(11) NOT NULL,
  `cd_depe_fun` int(11) NOT NULL,
  `cd_chv_fun` varchar(10) NOT NULL,
  `dt_acss` date NOT NULL,
  `hr_acss` time NOT NULL,
  `cd_end_ip` varchar(20) DEFAULT NULL,
  `tx_url_ogm` varchar(250) DEFAULT NULL,
  `nm_fun` varchar(250) DEFAULT NULL,
  `cd_sit_acss` int(11) NOT NULL,
  `tx_desc_tran_pmt` mediumtext NOT NULL,
  `cd_crg_fun` int(11) DEFAULT NULL,
  `browser` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`cd_log`,`dt_acss`),
  KEY `cd_ctu` (`cd_ctu`) USING BTREE,
  KEY `cd_sit_acss` (`cd_sit_acss`) USING BTREE,
  KEY `cd_crg_fun` (`cd_crg_fun`) USING BTREE,
  KEY `cd_depe_fun` (`cd_depe_fun`) USING BTREE,
  KEY `dt_acss` (`dt_acss`),
  KEY `chv_fun` (`cd_chv_fun`,`tx_url_ogm`,`dt_acss`)
) ENGINE=MyISAM AUTO_INCREMENT=37839581 DEFAULT CHARSET=latin1
/*!50100 PARTITION BY RANGE (YEAR(dt_acss))
SUBPARTITION BY LINEAR HASH (MONTH(dt_acss))
SUBPARTITIONS 10
(PARTITION p0 VALUES LESS THAN (2) ENGINE = MyISAM,
 PARTITION p1 VALUES LESS THAN (3) ENGINE = MyISAM,
 PARTITION p2 VALUES LESS THAN (4) ENGINE = MyISAM,
 PARTITION p3 VALUES LESS THAN (5) ENGINE = MyISAM,
 PARTITION p4 VALUES LESS THAN (6) ENGINE = MyISAM,
 PARTITION p5 VALUES LESS THAN (7) ENGINE = MyISAM,
 PARTITION p6 VALUES LESS THAN (8) ENGINE = MyISAM,
 PARTITION p7 VALUES LESS THAN (9) ENGINE = MyISAM,
 PARTITION p8 VALUES LESS THAN (10) ENGINE = MyISAM,
 PARTITION p9 VALUES LESS THAN (11) ENGINE = MyISAM,
 PARTITION p10 VALUES LESS THAN (12) ENGINE = MyISAM,
 PARTITION p11 VALUES LESS THAN (13) ENGINE = MyISAM,
 PARTITION p12 VALUES LESS THAN MAXVALUE ENGINE = MyISAM) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logDisec`
--

DROP TABLE IF EXISTS `logDisec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logDisec` (
  `cd_ctu` int(11) NOT NULL,
  `cd_depe_fun` int(11) NOT NULL,
  `cd_uor_eqp` int(11) NOT NULL,
  `cd_chv_fun` varchar(10) NOT NULL,
  `dt_acss` date NOT NULL,
  `hr_acss` time NOT NULL,
  `cd_end_ip` varchar(20) NOT NULL,
  `tx_url` varchar(300) NOT NULL,
  `id_sessao` varchar(300) NOT NULL,
  `nm_fun` varchar(255) NOT NULL,
  `cd_sit_acss` tinyint(1) NOT NULL COMMENT '1: Acesso Autorizado\n0: Acesso Negado',
  `cd_crg_fun` int(11) NOT NULL,
  `browser` varchar(255) NOT NULL,
  PRIMARY KEY (`dt_acss`,`id_sessao`,`cd_ctu`),
  KEY `cd_ctu` (`cd_ctu`) USING BTREE,
  KEY `cd_sit_acss` (`cd_sit_acss`) USING BTREE,
  KEY `cd_crg_fun` (`cd_crg_fun`) USING BTREE,
  KEY `cd_depe_fun` (`cd_depe_fun`) USING BTREE,
  KEY `dt_acss` (`dt_acss`),
  KEY `chv_fun` (`cd_chv_fun`,`tx_url`,`dt_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
/*!50100 PARTITION BY RANGE (YEAR(dt_acss))
SUBPARTITION BY LINEAR HASH (MONTH(dt_acss))
SUBPARTITIONS 10
(PARTITION p0 VALUES LESS THAN (2) ENGINE = MyISAM,
 PARTITION p1 VALUES LESS THAN (3) ENGINE = MyISAM,
 PARTITION p2 VALUES LESS THAN (4) ENGINE = MyISAM,
 PARTITION p3 VALUES LESS THAN (5) ENGINE = MyISAM,
 PARTITION p4 VALUES LESS THAN (6) ENGINE = MyISAM,
 PARTITION p5 VALUES LESS THAN (7) ENGINE = MyISAM,
 PARTITION p6 VALUES LESS THAN (8) ENGINE = MyISAM,
 PARTITION p7 VALUES LESS THAN (9) ENGINE = MyISAM,
 PARTITION p8 VALUES LESS THAN (10) ENGINE = MyISAM,
 PARTITION p9 VALUES LESS THAN (11) ENGINE = MyISAM,
 PARTITION p10 VALUES LESS THAN (12) ENGINE = MyISAM,
 PARTITION p11 VALUES LESS THAN (13) ENGINE = MyISAM,
 PARTITION p12 VALUES LESS THAN MAXVALUE ENGINE = MyISAM) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logExclusao`
--

DROP TABLE IF EXISTS `logExclusao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logExclusao` (
  `cd_excl` int(11) NOT NULL AUTO_INCREMENT,
  `tx_excl` varchar(45) NOT NULL COMMENT 'Será compara pelo final da URL acessada, por exemplo:\nhttp://disec.intranet.bb.com.br/header2014/images/lupa<.png>',
  `descricao` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`cd_excl`),
  UNIQUE KEY `tx_excl_UNIQUE` (`tx_excl`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_ctu`
--

DROP TABLE IF EXISTS `menu_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_ctu` (
  `cd_ctu_menu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cd_parent` int(10) unsigned NOT NULL DEFAULT '0',
  `cd_ctu` int(10) unsigned NOT NULL,
  `cd_item_menu` int(10) unsigned NOT NULL,
  `href` varchar(100) NOT NULL DEFAULT '#',
  PRIMARY KEY (`cd_ctu_menu`),
  KEY `FK_item_menu_idx` (`cd_item_menu`),
  KEY `FK_ctu_menu_dcr_ctu_idx` (`cd_ctu`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_grp_acss`
--

DROP TABLE IF EXISTS `menu_grp_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_grp_acss` (
  `cd_ctu_menu` int(10) unsigned NOT NULL,
  `cd_grp_acss` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cd_ctu_menu`,`cd_grp_acss`) USING BTREE,
  KEY `FK_menu_grp_acss_grp_acss_idx` (`cd_grp_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_itens`
--

DROP TABLE IF EXISTS `menu_itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_itens` (
  `cd_item_menu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nm_item_menu` varchar(45) NOT NULL,
  PRIMARY KEY (`cd_item_menu`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perc`
--

DROP TABLE IF EXISTS `perc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perc` (
  `cd_perc` int(11) NOT NULL DEFAULT '0',
  `nm_perc` varchar(45) NOT NULL,
  `nr_dd` int(11) NOT NULL,
  PRIMARY KEY (`cd_perc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sit_acss`
--

DROP TABLE IF EXISTS `sit_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_acss` (
  `cd_sit_acss` int(11) NOT NULL DEFAULT '0',
  `nm_sit_acss` varchar(45) NOT NULL,
  PRIMARY KEY (`cd_sit_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sit_ctu`
--

DROP TABLE IF EXISTS `sit_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sit_ctu` (
  `cd_sit_ctu` int(11) NOT NULL DEFAULT '0',
  `nm_sit_ctu` varchar(100) NOT NULL,
  PRIMARY KEY (`cd_sit_ctu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tb_etr_vsto`
--

DROP TABLE IF EXISTS `tb_etr_vsto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_etr_vsto` (
  `CD_ETR` tinyint(4) NOT NULL AUTO_INCREMENT,
  `CD_TIPO` tinyint(4) NOT NULL,
  `ETR` varchar(50) NOT NULL,
  PRIMARY KEY (`CD_ETR`),
  KEY `fk_tb_tipo_vsto_tb_etr_vsto` (`CD_TIPO`),
  KEY `fk_tb_tipo_vsto_tb_etr_vsto1` (`CD_TIPO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tp_ctu`
--

DROP TABLE IF EXISTS `tp_ctu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tp_ctu` (
  `cd_tp_ctu` int(11) NOT NULL DEFAULT '0',
  `nm_tp_ctu` varchar(100) NOT NULL,
  PRIMARY KEY (`cd_tp_ctu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `url_tipo`
--

DROP TABLE IF EXISTS `url_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_tipo` (
  `CD_URL` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `NM_URL` varchar(45) NOT NULL,
  PRIMARY KEY (`CD_URL`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COMMENT='Relaciona os tipos de url';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `acss`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `acss` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `acss`;

--
-- Table structure for table `ctu_grp`
--

DROP TABLE IF EXISTS `ctu_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ctu_grp` (
  `cd_ctu` int(11) NOT NULL,
  `cd_gr_acss` int(11) NOT NULL,
  PRIMARY KEY (`cd_ctu`,`cd_gr_acss`),
  KEY `fk_ctu_grp_grp_acss1` (`cd_gr_acss`),
  KEY `fk_ctu_grp_dcr_ctu1` (`cd_ctu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `grp_acss`
--

DROP TABLE IF EXISTS `grp_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grp_acss` (
  `cd_gr_acss` int(11) NOT NULL COMMENT 'Codigo do grupo de acessos',
  `nm_gr_acss` varchar(50) NOT NULL COMMENT 'Nome do grupo de acessos',
  `dt_gr` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data de criacao do grupo',
  `cd_tip_pbco` tinyint(3) unsigned NOT NULL COMMENT 'Codigo do publico',
  PRIMARY KEY (`cd_gr_acss`),
  KEY `IDX_DT_GR` (`dt_gr`),
  KEY `FK_grp_acss_tp_pbco` (`cd_tip_pbco`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER grp_acss_log_up BEFORE UPDATE ON grp_acss
FOR EACH ROW
BEGIN
SET @user=user();

-- INSERT INTO agile.grp_acss_log (dt_log, cd_gr_acss, nm_gr_acss, dt_gr, cd_tip_pbco, user_update) VALUES (NOW(), OLD.cd_gr_acss, OLD.nm_gr_acss, OLD.dt_gr, OLD.cd_tip_pbco, @user);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `grp_pfl`
--

DROP TABLE IF EXISTS `grp_pfl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grp_pfl` (
  `cd_grp_acss` int(11) NOT NULL,
  `cd_pfl_acss` int(11) NOT NULL,
  PRIMARY KEY (`cd_grp_acss`,`cd_pfl_acss`),
  KEY `fk_grp_pfl_grp_acss1` (`cd_grp_acss`),
  KEY `fk_grp_pfl_pfl_acss1` (`cd_pfl_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pfl_acss`
--

DROP TABLE IF EXISTS `pfl_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pfl_acss` (
  `cd_pfl_acss` int(11) NOT NULL COMMENT 'Codigo do perfil de acesso',
  `nm_pfl_acss` varchar(50) NOT NULL COMMENT 'Nome do perfil de acesso',
  `cd_tp_pfl_acss` tinyint(4) NOT NULL COMMENT 'Codigo do Perfil de acesso',
  `sql_val` varchar(800) NOT NULL COMMENT 'Sql de validacao do perfil',
  PRIMARY KEY (`cd_pfl_acss`),
  KEY `fk_pfl_acss_tp_pfl_acss` (`cd_tp_pfl_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tip_pbco`
--

DROP TABLE IF EXISTS `tip_pbco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tip_pbco` (
  `cd_tip_pbco` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nm_tip_pboc` varchar(45) NOT NULL,
  PRIMARY KEY (`cd_tip_pbco`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='Relaciona os tipos de publicos para os grupos de acessos.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tp_pfl_acss`
--

DROP TABLE IF EXISTS `tp_pfl_acss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tp_pfl_acss` (
  `cd_tp_pfl_acss` tinyint(4) NOT NULL COMMENT 'Codigo do tipo de perfil',
  `nm_tp_pfl_acss` varchar(50) NOT NULL COMMENT 'Nome do tipo de perfil',
  PRIMARY KEY (`cd_tp_pfl_acss`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usu_chv`
--

DROP TABLE IF EXISTS `usu_chv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usu_chv` (
  `CD_USU` char(8) NOT NULL,
  `CHV` char(4) NOT NULL,
  PRIMARY KEY (`CD_USU`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Relaciona usuarios as suas respectivas chaves de homologacao';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usu_grp`
--

DROP TABLE IF EXISTS `usu_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usu_grp` (
  `cd_usu` char(8) NOT NULL COMMENT 'Chave do usuario',
  `gr_acss` varchar(300) NOT NULL COMMENT 'Codigo do grupo de acesso',
  `dt_gr` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data de consulta aos grupos de acesso do usuario',
  PRIMARY KEY (`cd_usu`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Relaciona os usuarios aos seus grupos de acessos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `mstNovo`
--

USE `mstNovo`;

--
-- Final view structure for view `PRF_PSO_GAT`
--

/*!50001 DROP VIEW IF EXISTS `PRF_PSO_GAT`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`F8716641`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `PRF_PSO_GAT` AS select `d`.`CD_PRF` AS `cd_prf`,`d`.`CD_SBDD` AS `cd_sbdd`,`d`.`CD_PRF` AS `prf_orig`,`d`.`CD_SBDD` AS `sbdd_orig`,0 AS `campo5`,`dp`.`depe_hrqo` AS `depe_hrqo`,0 AS `campo7` from (`depe` `d` join `PRF_PSO_GAT_sub` `dp` on((`dp`.`CD_PRF` = `d`.`CD_PRF`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `PRF_PSO_GAT_sub`
--

/*!50001 DROP VIEW IF EXISTS `PRF_PSO_GAT_sub`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`F8716641`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `PRF_PSO_GAT_sub` AS select `d`.`CD_PRF` AS `CD_PRF`,`d`.`CD_SBDD` AS `CD_SBDD`,`mstNovo`.`depe`.`CD_PRF` AS `depe_hrqo`,`mstNovo`.`depe`.`NM_UOR_RED` AS `nm_hrqo` from (`depe` `d` join `depe` on((`mstNovo`.`depe`.`CD_UOR` = `d`.`UOR_HRQO`))) where ((`d`.`CD_TIP_UOR` = 113) and (`d`.`CD_EST_FCN` = 2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `PrfSop1_sub`
--

/*!50001 DROP VIEW IF EXISTS `PrfSop1_sub`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `PrfSop1_sub` AS select 1 AS `CD_PRF`,1 AS `CD_SBDD`,1 AS `depe_hrqo`,1 AS `nm_hrqo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `depe_hrqo`
--

/*!50001 DROP VIEW IF EXISTS `depe_hrqo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `depe_hrqo` AS select 1 AS `CD_UOR`,1 AS `CD_PRF`,1 AS `NM_UOR`,1 AS `CD_UOR_HRQO`,1 AS `CD_PRF_HRQO`,1 AS `NM_UOR_HRQO` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `depe_hrqo_uf`
--

/*!50001 DROP VIEW IF EXISTS `depe_hrqo_uf`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `depe_hrqo_uf` AS select 1 AS `CD_UOR`,1 AS `CD_PRF`,1 AS `NM_UOR`,1 AS `CD_UOR_HRQO`,1 AS `CD_PRF_HRQO`,1 AS `NM_UOR_HRQO`,1 AS `SG_UF_UOR`,1 AS `SG_UF_UOR_HRQO` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `depe_jrdc_hrqo`
--

/*!50001 DROP VIEW IF EXISTS `depe_jrdc_hrqo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `depe_jrdc_hrqo` AS select 1 AS `CD_UOR`,1 AS `CD_PRF`,1 AS `NM_UOR_RED`,1 AS `CD_PRF_HRQO` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `depe_tip_uor_hrqo`
--

/*!50001 DROP VIEW IF EXISTS `depe_tip_uor_hrqo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `depe_tip_uor_hrqo` AS select 1 AS `CD_UOR`,1 AS `UOR_HRQO`,1 AS `CD_PRF`,1 AS `NM_UOR_RED`,1 AS `cd_tip_uor` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `uor_jrdd_jrdt`
--

/*!50001 DROP VIEW IF EXISTS `uor_jrdd_jrdt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `uor_jrdd_jrdt` AS select 1 AS `CD_UOR_JRDD`,1 AS `CD_PRF`,1 AS `CD_SBDD`,1 AS `NM_UOR_RED`,1 AS `CD_UOR_JRDT`,1 AS `CD_TIP_UOR`,1 AS `NM_TIP_UOR_RED` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Current Database: `intranet`
--

USE `intranet`;

--
-- Final view structure for view `ctu_grp`
--

/*!50001 DROP VIEW IF EXISTS `ctu_grp`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `ctu_grp` AS select `acss`.`ctu_grp`.`cd_ctu` AS `cd_ctu`,`acss`.`ctu_grp`.`cd_gr_acss` AS `cd_gr_acss` from `acss`.`ctu_grp` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Current Database: `acss`
--

USE `acss`;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-03 12:58:30
