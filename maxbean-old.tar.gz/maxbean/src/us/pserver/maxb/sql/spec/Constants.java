/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package us.pserver.maxb.sql.spec;


/**
 *
 * @author juno
 */
public class Constants {
	
	public static final String SQL_SHOW_COLS = "showColumns";
	
	public static final String SQL_SHOW_TABLES = "showTables";
	
	public static final String PARAM_SCHEMA = "$SCHEMA";
	
	public static final String PARAM_TABLE = "$TABLE";
	
}
